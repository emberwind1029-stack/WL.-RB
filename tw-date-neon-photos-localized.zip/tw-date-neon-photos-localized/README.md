# jp-date-neon-mobile-line-finalfix-toprestore

- 去掉顶部多出来的 LINE相談 按钮
- 恢复手机端顶部原来的标题样式
- 保留首页主按钮、底部 LINE 按钮、女嘉宾卡片按钮的跳转修复

- 底部中间 LINE相談 按钮恢复为霓虹渐变高亮样式
